from array import array
import numpy as np
from l26_geometry_reader.keys_helpers import *

DELTA_U_DEFAULT = 1.0
DELTA_THETA_DEFAULT = np.pi / 180


class Discretizer:
    """
        part: dictionary containing the contours
        select either of them
        arc_delta_u:     arc interpolation by circumference [in mm]
        arc_delta_theta: arc interpolation by angle         [in radians]
    """
    @staticmethod
    def discretize_geometry(part: dict, arc_delta_u: float = DELTA_U_DEFAULT, arc_delta_theta: float = None) -> (np.ndarray, [np.ndarray]):

        assert (arc_delta_u is not None) != (arc_delta_theta is not None),\
            'Either arc_delta_u or arc_delta_theta is required!'

        outer_curve = get(part, 'outer_curve')
        outer_curve_segments = get(outer_curve, 'segments')

        outer_contour = Discretizer.discretize_segments(outer_curve_segments, arc_delta_u, arc_delta_theta)

        inner_contours = []
        inner_curves = try_get(part, 'inner_curves')

        if inner_curves is not None:
            for inner_curve in inner_curves:
                inner_curve_segments = get(inner_curve, 'segments')
                inner_contours.append(Discretizer.discretize_segments(inner_curve_segments, arc_delta_u, arc_delta_theta))

        return outer_contour, inner_contours

    @staticmethod
    def discretize_segments(segments: [dict], arc_delta_u: float = DELTA_U_DEFAULT, arc_delta_theta: float = None) -> np.ndarray:

        contour = []

        for segment in segments:
            if Discretizer.segment_is_point(segment):
                Discretizer.__discretize_point(contour, segment)
            elif Discretizer.segment_is_line(segment):
                Discretizer.__discretize_line(contour, segment)
            elif Discretizer.segment_is_arc(segment):
                Discretizer.__discretize_arc(contour, segment, arc_delta_u, arc_delta_theta)
            else:
                raise Exception(f"Unable to identify segment type of:\n{segment}")

        return np.array(contour, dtype=float)

    @staticmethod
    def segment_is_point(segment: dict) -> bool:
        if not has(segment, 'point'):
            return False

        point = get(segment, 'point')
        return has(point, 'x') and has(point, 'y')

    @staticmethod
    def segment_is_line(segment: dict) -> bool:
        return (has(segment, 'start') and
                has(segment, 'end'))

    @staticmethod
    def segment_is_arc(segment: dict) -> bool:
        return (has(segment, 'center') and
                has(segment, 'radius') and
                has(segment, 'absolute_start_angle') and
                has(segment, 'signed_span_angle'))

    @staticmethod
    def discretize_point(point: dict) -> [np.ndarray]:
        contour = []
        Discretizer.__discretize_point(contour, point)
        return contour

    @staticmethod
    def __discretize_point(contour: list, segment: dict) -> None:
        point = get(segment, 'point')
        px = get(point, 'x')
        py = get(point, 'y')
        contour.append(np.array([px, py], dtype=float))

    @staticmethod
    def discretize_line(line: dict) -> [np.ndarray]:
        contour = []
        Discretizer.__discretize_line(contour, line)
        return contour

    @staticmethod
    def __discretize_line(contour: list, line: dict) -> None:
        start = get(line, 'start')
        spx = get(start, 'x')
        spy = get(start, 'y')
        contour.append(np.array([spx, spy], dtype=float))

        end = get(line, 'end')
        epx = get(end, 'x')
        epy = get(end, 'y')
        contour.append(np.array([epx, epy], dtype=float))

    @staticmethod
    def discretize_arc(arc: dict, delta_u: float = 1.0, delta_theta: float = None) -> [np.ndarray]:
        contour = []
        Discretizer.__discretize_arc(contour, arc, delta_u, delta_theta)
        return contour

    @staticmethod
    def __discretize_arc(contour: list, arc: dict, delta_u: float = None, delta_theta: float = None) -> None:
        center = get(arc, 'center')
        radius = get(arc, 'radius')
        signed_span_angle = get(arc, 'signed_span_angle')
        absolute_start_angle = get(arc, 'absolute_start_angle')

        if signed_span_angle == -0.0 or signed_span_angle == 0.0:
            signed_span_angle = 2 * np.pi

        cpx = get(center, 'x')
        cpy = get(center, 'y')

        if delta_u is not None:
            points = list(Discretizer.discretize_arc_by_circumference(
                radius, absolute_start_angle, signed_span_angle, [cpx, cpy], delta_u))
        elif delta_theta is not None:
            points = list(Discretizer.discretize_arc_by_angle(
                radius, absolute_start_angle, signed_span_angle, [cpx, cpy], delta_theta))
        else:
            raise Exception('Either delta_u or delta_theta required!')

        contour.extend(points)

    @staticmethod
    def discretize_arc_by_circumference(radius, start_angle, span_angle, center, delta_u: float = DELTA_U_DEFAULT) -> np.ndarray:
        center = np.array([center], dtype=float)
        U = np.abs(span_angle) * radius
        num = int(U / delta_u)
        theta = np.linspace(start_angle, start_angle + span_angle, num)
        return radius * np.stack([np.cos(theta), np.sin(theta)], axis=1) + center

    @staticmethod
    def discretize_arc_by_angle(radius, start_angle, span_angle, center, delta_theta: float = DELTA_THETA_DEFAULT) -> np.ndarray:
        center = np.array([center], dtype=float)
        theta = np.arange(start_angle, start_angle + span_angle, delta_theta * np.sign(span_angle))
        return radius * np.stack([np.cos(theta), np.sin(theta)], axis=1) + center
