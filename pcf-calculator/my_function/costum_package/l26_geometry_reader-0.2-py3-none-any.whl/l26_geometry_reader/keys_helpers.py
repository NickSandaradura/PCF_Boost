# support for alias keys in geometry

__alias = {
    "start": ["start_point"],
    "end": ["end_point"],
    "center": ["center_point"]
}


def has(obj, key):
    if key in obj:
        return True
    if key in __alias:
        for alias in __alias[key]:
            if alias in obj:
                return True
    return False


def get(obj, key):
    if key in obj:
        return obj[key]
    if key in __alias:
        for alias in __alias[key]:
            if alias in obj:
                return obj[alias]
    raise Exception(f"'{key}' not found")


def try_get(obj, key):
    if key in obj:
        return obj[key]
    if key in __alias:
        for alias in __alias[key]:
            if alias in obj:
                return obj[alias]
    return None
